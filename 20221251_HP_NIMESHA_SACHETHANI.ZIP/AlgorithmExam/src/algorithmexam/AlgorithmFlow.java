import java.util.*;
import java.io.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author ASUS 
 */


/**
 *The algorithm Ford-Fulkerson algorithm using the Edmonds-Karp improvement(BFS to find augmenting paths) selected 
 because it suits best to compute the maximum flow for a network
 */
public class AlgorithmFlow {
    //  to represent an edge in the flow network
    private class Edge {
        private int capacity;
        private int flow;

        public Edge(int capacity) {
            this.capacity = capacity;
            this.flow = 0;
        }

        public int getCapacity() {
            return capacity;
        }

        public int getFlow() {
            return flow;
        }

        public void setFlow(int flow) {
            this.flow = flow;
        }

        public int getResidualCapacity() {
            return capacity - flow;
        }
        
        @Override
        public String toString() {
            return "capacity=" + capacity + ", flow=" + flow;
        }
    }

    private Map<Integer, Map<Integer, Edge>> graph;
    private Set<Integer> vertices;
    private int numNodes;
    private int source;
    private int sink;

    /**
     * Constructs an empty flow network.
     */
    public AlgorithmFlow() {
        this.graph = new HashMap<>();
        this.vertices = new HashSet<>();
        this.numNodes = 0;
        this.source = 0;
        this.sink = 0;
    }

    /**
     * Adds a vertex to the flow network.
     
     * true if the vertex was added, false if it already existed
     */
    public boolean addVertex(int vertex) {
        if (!graph.containsKey(vertex)) {
            graph.put(vertex, new HashMap<>());
            vertices.add(vertex);
            return true;
        }
        return false;
    }

    /**
     * Adds an edge to the flow network .
     * adds the reverse edge with 0 capacity 
     * 
     * @param source The source vertex
     * @param target The target vertex
     * @param capacity The capacity of the edge
     */
    public void addEdge(int source, int target, int capacity) {
        
        addVertex(source);
        addVertex(target);
        
       
        graph.get(source).put(target, new Edge(capacity));
        
        // Add the reverse edge with 0 capacity if it doesn't exist
        if (!graph.get(target).containsKey(source)) {
            graph.get(target).put(source, new Edge(0));
        }
    }

       public int getCapacity(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getCapacity();
        }
        return 0;
    }

    /** Gets the current flow through an edge*/
    public int getFlow(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getFlow();
        }
        return 0;
    }

   
    public boolean setFlow(int source, int target, int flow) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            graph.get(source).get(target).setFlow(flow);
            return true;
        }
        return false;
    }

   
    public int getResidualCapacity(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getResidualCapacity();
        }
        return 0;
    }

    /* Gets all neighbors of a vertex.  */
    public List<Integer> getNeighbors(int vertex) {
        if (graph.containsKey(vertex)) {
            return new ArrayList<>(graph.get(vertex).keySet());
        }
        return new ArrayList<>();
    }

    /* Gets all vertices in the network.*/
    
    public List<Integer> getVertices() {
        return new ArrayList<>(vertices);
    }

    /**
     * Gets the number of nodes in the network and return number of nodes
     
     */
    public int getNumNodes() {
        return numNodes;
    }

    /**
     * Gets the source node of the network.
     * 
     * @return The source node
     */
    public int getSource() {
        return source;
    }
    
public int getEdgeCount() {
        int count = 0;
        for (Integer vertex : graph.keySet()) {
            count += graph.get(vertex).size();
        }
        return count / 2; // Divide by 2 because we're counting each edge twice (forward and reverse)
    }
    public boolean augmentFlow(List<Integer> path, int flow) {
        if (path == null || path.size() < 2 || flow <= 0) {
            return false;
        }
        
       
        for (int i = 0; i < path.size() - 1; i++) {
            Integer u = path.get(i);
            Integer v = path.get(i + 1);
            
            // Increase flow 
            int currentFlow = getFlow(u, v);
            setFlow(u, v, currentFlow + flow);
            
            // Decrease flow 
            currentFlow = getFlow(v, u);
            setFlow(v, u, currentFlow - flow);
        }
        
        return true;
    }

    /**
     * Resets all flows to 0.
     */
    public void resetFlow() {
        for (Integer u : graph.keySet()) {
            for (Integer v : graph.get(u).keySet()) {
                graph.get(u).get(v).setFlow(0);
            }
        }
    }

    /**
      Uses BFS to find an augmenting path in the residual network.
   
    */
    private List<Integer> findAugmentingPath() {
        
        Map<Integer, Integer> predecessor = new HashMap<>();
        Queue<Integer> queue = new LinkedList<>();
        
        // Start BFS 
        queue.add(source);
        predecessor.put(source, null); 
        // BFS until we find the sink or exhaust all vertices
        while (!queue.isEmpty() && !predecessor.containsKey(sink)) {
            Integer u = queue.poll();
            
           
            for (Integer v : getNeighbors(u)) {
               
                if (!predecessor.containsKey(v) && getResidualCapacity(u, v) > 0) {
                    predecessor.put(v, u);
                    queue.add(v);
                }
            }
        }
        
        // If we didn't reach the sink, there is no augmenting path
        if (!predecessor.containsKey(sink)) {
            return null;
        }
        
        // Reconstruct the path from source to sink
        List<Integer> path = new ArrayList<>();
        Integer current = sink;
        while (current != null) {
            path.add(current);
            current = predecessor.get(current);
        }
        
        return path;
    }

    private int computePathFlow(List<Integer> path) {
        int maxFlow = Integer.MAX_VALUE;
        
        for (int i = 0; i < path.size() - 1; i++) {
            Integer u = path.get(i);
            Integer v = path.get(i + 1);
            maxFlow = Math.min(maxFlow, getResidualCapacity(u, v));
        }
        
        return maxFlow;
    }

  
    public int computeMaximumFlow(boolean verbose) {
        resetFlow(); // Start with zero flow
        
        if (verbose) {
            System.out.println("Computing maximum flow for network with " + numNodes + 
                               " nodes (source: " + source + ", sink: " + sink + ")");
            System.out.println("Initial flow: 0");
        }
        
        int iterationCount = 0;
        int totalFlow = 0;
        
       
        List<Integer> path;
        while ((path = findAugmentingPath()) != null) {
            iterationCount++;
            
            
            int pathFlow = computePathFlow(path);
            totalFlow += pathFlow;
            
            // Augment the flow along the path
            augmentFlow(path, pathFlow);
            
            if (verbose) {
                System.out.println("\nIteration " + iterationCount + ":");
                System.out.println("Found augmenting path: " + pathToString(path));
                System.out.println("Bottleneck capacity: " + pathFlow);
                System.out.println("Flow after augmentation: " + totalFlow);
                if (iterationCount <= 10) {  // Limit detailed network state to first 10 iterations
                    System.out.println("Network state after augmentation:");
                    printNetworkState();
                }
            }
        }
        
        if (verbose) {
            System.out.println("\nMaximum flow computation complete after " + iterationCount + " iterations");
            System.out.println("Maximum flow: " + totalFlow);
            System.out.println("\nFinal network state:");
            printNetworkState();
            
            // Print the min-cut
            printMinCut();
        }
        
        return totalFlow;
    }
    
    
    //Finds and prints the minimum 
    
    private void printMinCut() {
        // Run BFS from source in the residual network to find reachable vertices
        Set<Integer> reachable = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();
        
        queue.add(source);
        reachable.add(source);
        
        while (!queue.isEmpty()) {
            Integer u = queue.poll();
            
            for (Integer v : getNeighbors(u)) {
                if (!reachable.contains(v) && getResidualCapacity(u, v) > 0) {
                    reachable.add(v);
                    queue.add(v);
                }
            }
        }
       
        System.out.println("\nMinimum Cut:");
        int cutCapacity = 0;
        
        for (Integer u : reachable) {
            for (Integer v : getNeighbors(u)) {
                if (!reachable.contains(v)) {
                    int capacity = getCapacity(u, v);
                    if (capacity > 0) { // Only consider forward edges
                        System.out.println("  Edge " + u + " -> " + v + " (capacity: " + capacity + ")");
                        cutCapacity += capacity;
                    }
                }
            }
        }
        
        System.out.println("Min-cut capacity: " + cutCapacity);
    }
    
    
    private String pathToString(List<Integer> path) {
        if (path == null || path.isEmpty()) {
            return "[]";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(path.get(0));
        
        for (int i = 1; i < path.size(); i++) {
            sb.append(" -> ").append(path.get(i));
        }
        
        return sb.toString();
    }
   

    private void printNetworkState() {
        List<Integer> sortedVertices = new ArrayList<>(graph.keySet());
        Collections.sort(sortedVertices);
        
        for (Integer u : sortedVertices) {
            List<Integer> sortedNeighbors = new ArrayList<>(graph.get(u).keySet());
            Collections.sort(sortedNeighbors);
            
            for (Integer v : sortedNeighbors) {
                Edge edge = graph.get(u).get(v);
                
                if (edge.getCapacity() > 0) {
                    System.out.println("  " + u + " -> " + v + ": capacity=" + 
                                       edge.getCapacity() + ", flow=" + edge.getFlow());
                }
            }
        }
    }

   
    public static AlgorithmFlow parseFromFile(String filename) throws IOException {
        AlgorithmFlow network = new AlgorithmFlow();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        
        try {
            
            String line = reader.readLine();
            if (line == null) {
                throw new IllegalArgumentException("Empty file");
            }
            
            int numNodes = Integer.parseInt(line.trim());
            if (numNodes <= 1) {
                throw new IllegalArgumentException("Number of nodes must be at least 2");
            }
            
            network.numNodes = numNodes;
            network.source = 0;
            network.sink = numNodes - 1;
            
          
            for (int i = 0; i < numNodes; i++) {
                network.addVertex(i);
            }
            
            // Read edges
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                
                String[] parts = line.split("\\s+");
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Each edge line must contain exactly 3 integers");
                }
                
                int source = Integer.parseInt(parts[0]);
                int target = Integer.parseInt(parts[1]);
                int capacity = Integer.parseInt(parts[2]);
                
                if (source < 0 || source >= numNodes) {
                    throw new IllegalArgumentException("Source node out of range: " + source);
                }
                if (target < 0 || target >= numNodes) {
                    throw new IllegalArgumentException("Target node out of range: " + target);
                }
                if (capacity < 0) {
                    throw new IllegalArgumentException("Capacity must be non-negative: " + capacity);
                }
                
                network.addEdge(source, target, capacity);
            }
            
            return network;
        } finally {
            reader.close();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Flow Network with " + numNodes + " nodes:\n");
        sb.append("Source: " + source + ", Sink: " + sink + "\n");
        
        List<Integer> sortedVertices = new ArrayList<>(graph.keySet());
        Collections.sort(sortedVertices);
        
        for (Integer u : sortedVertices) {
            sb.append("Vertex " + u + ":\n");
            
            List<Integer> sortedNeighbors = new ArrayList<>(graph.get(u).keySet());
            Collections.sort(sortedNeighbors);
            
            for (Integer v : sortedNeighbors) {
                Edge edge = graph.get(u).get(v);
                // Only print edges with positive capacity (original edges, not residual edges)
                if (edge.getCapacity() > 0) {
                    sb.append("  -> " + v + ": capacity=")
                      .append(edge.getCapacity() + ", flow=")
                      .append(edge.getFlow() + "\n");
                }
            }
        }
        return sb.toString();
    }

    
    public static void main(String[] args) {
        try {
           
            System.out.println("===== EXAMPLE NETWORK =====");
            createSampleNetworkFile("sample_network.txt");
            FlowNetwork network = FlowNetwork.parseFromFile("sample_network.txt");
            System.out.println("Initial network:");
            System.out.println(network);
            
            System.out.println("\nComputing maximum flow...");
            int maxFlow = network.computeMaximumFlow(true);
            System.out.println("\nVerified maximum flow: " + maxFlow);
            
           
            System.out.println("\n\n===== COMPLEX NETWORK =====");
            createComplexNetworkFile("complex_network.txt");
            network = AlgorithmFlow.parseFromFile("complex_network.txt");
            System.out.println("Initial complex network:");
            System.out.println(network);
            
            System.out.println("\nComputing maximum flow for complex network...");
            maxFlow = network.computeMaximumFlow(true);
            System.out.println("\nVerified maximum flow for complex network: " + maxFlow);
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    
    private static void createSampleNetworkFile(String filename) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(filename));
        try {
            writer.println("4");
            writer.println("0 1 6");
            writer.println("0 2 4");
            writer.println("1 2 2");
            writer.println("1 3 3");
            writer.println("2 3 5");
        } finally {
            writer.close();
        }
        System.out.println("Sample network file created: " + filename);
    }
    
    
    private static void createComplexNetworkFile(String filename) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(filename));
        try {
            writer.println("6");
            writer.println("0 1 10");
            writer.println("0 2 8");
            writer.println("1 2 5");
            writer.println("1 3 4");
            writer.println("2 3 5");
            writer.println("2 4 3");
            writer.println("3 4 7");
            writer.println("3 5 10");
            writer.println("4 5 6");
        } finally {
            writer.close();
        }
        System.out.println("Complex network file created: " + filename);
    }
}



