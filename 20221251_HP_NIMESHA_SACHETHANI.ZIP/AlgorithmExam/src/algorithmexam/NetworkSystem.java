import java.util.*;
import java.io.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
    

// adjacency list for a flow  of network 
 
public class NetworkSystem {
    
    private class Edge {
        private int capacity;
        private int flow;

        public Edge(int capacity) {
            this.capacity = capacity;
            this.flow = 0;
        }

        public int getCapacity() {
            return capacity;
        }

        public int getFlow() {
            return flow;
        }

        public void setFlow(int flow) {
            this.flow = flow;
        }

        public int getResidualCapacity() {
            return capacity - flow;
        }
    }

    private Map<String, Map<String, Edge>> graph;
    private Set<String> vertices;
// empty flow network.
    
    public NetworkSystem() {
        this.graph = new HashMap<>();
        this.vertices = new HashSet<>();
    }

    
    public boolean plusVertex(String vertex) {
        if (!graph.containsKey(vertex)) {
            graph.put(vertex, new HashMap<>());
            vertices.add(vertex);
            return true;
        }
        return false;
    }

   
    public void plusEdge(String source, String target, int capacity) {
       
        plusVertex(source);
        plusVertex(target);
        
        
        graph.get(source).put(target, new Edge(capacity));
        
        
        if (!graph.get(target).containsKey(source)) {
            graph.get(target).put(source, new Edge(0));
        }
    }

   
    public int getCapacity(String source, String target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getCapacity();
        }
        return 0;
    }

    public int getFlow(String source, String target) {  
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getFlow();
        }
        return 0;
    }

    
    public boolean setFlow(String source, String target, int flow) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            graph.get(source).get(target).setFlow(flow);
            return true;
        }
        return false;
    }

    
    public int getcontainCapacity(String source, String target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getcontainCapacity();
        }
        return 0;
    }

    
    public List<String> getNeighbors(String vertex) {
        if (graph.containsKey(vertex)) {
            return new ArrayList<>(graph.get(vertex).keySet());
        }
        return new ArrayList<>();
    }

    
    public List<String> getVertices() {
        return new ArrayList<>(vertices);
    }

   
    public int getEdgeCount() {
        int count = 0;
        for (String vertex : graph.keySet()) {
            count += graph.get(vertex).size();
        }
        return count / 2; 
    }

    public boolean augmentFlow(List<String> path, int flow) {
        if (path == null || path.size() < 2 || flow <= 0) {
            return false;
        }
        
        
        for (int i = 0; i < path.size() - 1; i++) {
            String u = path.get(i);
            String v = path.get(i + 1);
            
            
            int currentFlow = getFlow(u, v);
            setFlow(u, v, currentFlow + flow);
            
            
            currentFlow = getFlow(v, u);
            setFlow(v, u, currentFlow - flow);
        }
        
        return true;
    }

   
    public void resetFlow() {
        for (String u : graph.keySet()) {
            for (String v : graph.get(u).keySet()) {
                graph.get(u).get(v).setFlow(0);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Flow Network:\n");
        List<String> sortedVertices = new ArrayList<>(graph.keySet());
        Collections.sort(sortedVertices);
        
        for (String u : sortedVertices) {
            sb.append("Vertex ").append(u).append(":\n");
            
            List<String> sortedNeighbors = new ArrayList<>(graph.get(u).keySet());
            Collections.sort(sortedNeighbors);
            
            for (String v : sortedNeighbors) {
                Edge edge = graph.get(u).get(v);
                sb.append("  -> ").append(v).append(": capacity=")
                  .append(edge.getCapacity()).append(", flow=")
                  .append(edge.getFlow()).append("\n");
            }
        }
        return sb.toString();
    }

   
    public static void main(String[] args) {
        
        NetworkSystem network = new NetworkSystem();
        
        
        network.plusEdge("s", "a", 10);
        network.plusEdge("s", "b", 8);
        network.plusEdge("a", "b", 5);
        network.plusEdge("a", "t", 7);
        network.plusEdge("b", "t", 10);
        
        System.out.println("Initial network:");
        System.out.println(network);
        
       
        network.setFlow("s", "a", 7);
        network.setFlow("a", "t", 7);
        network.setFlow("s", "b", 8);
        network.setFlow("b", "t", 8);
        network.setFlow("a", "b", 0);
        
        
        network.setFlow("a", "s", -7);
        network.setFlow("t", "a", -7);
        network.setFlow("b", "s", -8);
        network.setFlow("t", "b", -8);
        network.setFlow("b", "a", 0);
        
        
        System.out.println("\nNetwork after flow assignment:");
        System.out.println(network);
        
        
        int totalFlow = 0;
        List<String> neighbors = network.getNeighbors("s");
        for (String v : neighbors) {
            totalFlow += network.getFlow("s", v);
        }
        System.out.println("\nTotal flow from source to sink: " + totalFlow);
    }
}






































