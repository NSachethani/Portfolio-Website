/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package algorithmexam;

/**
 *
 * @author ASUS
 */
public class Parser {
    
    private class Edge {
        private int capacity;
        private int flow;

        public Edge(int capacity) {
            this.capacity = capacity;
            this.flow = 0;
        }

        public int getCapacity() {
            return capacity;
        }

        public int getFlow() {
            return flow;
        }

        public void setFlow(int flow) {
            this.flow = flow;
        }

        public int getcontainCapacity() {
            return capacity - flow;
        }
    }

    private Map<Integer, Map<Integer, Edge>> graph;
    private Set<Integer> vertices;
    private int numNodes;
    private int source;
    private int sink;

    
    public Parser() {
        this.graph = new HashMap<>();
        this.vertices = new HashSet<>();
        this.numNodes = 0;
        this.source = 0;
        this.sink = 0;
    }

   
    public boolean plusVertex(int vertex) {
        if (!graph.containsKey(vertex)) {
            graph.put(vertex, new HashMap<>());
            vertices.add(vertex);
            return true;
        }
        return false;
    }

 
    public void plusEdge(int source, int target, int capacity) {
        
        plusVertex(source);
        plusVertex(target);
        
       
        graph.get(source).put(target, new Edge(capacity));
        
     
        if (!graph.get(target).containsKey(source)) {
            graph.get(target).put(source, new Edge(0));
        }
    }

   
    public int getCapacity(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getCapacity();
        }
        return 0;
    }

   
    public int getFlow(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getFlow();
        }
        return 0;
    }

    public boolean setFlow(int source, int target, int flow) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            graph.get(source).get(target).setFlow(flow);
            return true;
        }
        return false;
    }

  
    public int getcontainCapacity(int source, int target) {
        if (graph.containsKey(source) && graph.get(source).containsKey(target)) {
            return graph.get(source).get(target).getContainCapacity();
        }
        return 0;
    }

    
    public List<Integer> getNeighbors(int vertex) {
        if (graph.containsKey(vertex)) {
            return new ArrayList<>(graph.get(vertex).keySet());
        }
        return new ArrayList<>();
    }

   
    public List<Integer> getVertices() {
        return new ArrayList<>(vertices);
    }

    public int getNumNodes() {
        return numNodes;
    }

   
    public int getSource() {
        return source;
    }

   
    public int getSink() {
        return sink;
    }

    public int getEdgeCount() {
        int count = 0;
        for (Integer vertex : graph.keySet()) {
            count += graph.get(vertex).size();
        }
        return count / 2; 
    }

    public boolean augmentFlow(List<Integer> path, int flow) {
        if (path == null || path.size() < 2 || flow <= 0) {
            return false;
        }
        
      
        for (int i = 0; i < path.size() - 1; i++) {
            Integer u = path.get(i);
            Integer v = path.get(i + 1);
          
            int currentFlow = getFlow(u, v);
            setFlow(u, v, currentFlow + flow);
            
            
            currentFlow = getFlow(v, u);
            setFlow(v, u, currentFlow - flow);
        }
        
        return true;
    }

   
    public void resetFlow() {
        for (Integer u : graph.keySet()) {
            for (Integer v : graph.get(u).keySet()) {
                graph.get(u).get(v).setFlow(0);
            }
        }
    }

    public static Network parseFromFile(String filename) throws IOException {
        Network system = new Network();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        
        try {
            // to Read the number of nodes
            String line = reader.readLine();
            if (line == null) {
                throw new IllegalArgumentException("Empty file");
            }
            
            int numberNodes = Integer.parseInt(line.trim());
            if (numberNodes <= 1) {
                throw new IllegalArgumentException("Number of nodes must be at least 2");
            }
            
            system.numNodes = numberNodes;
            system.source = 0;
            system.sink = numberNodes - 1;
            
           
            for (int i = 0; i < numberNodes; i++) {
                system.plusVertex(i);
            }
            
            
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                
                String[] parts = line.split("\\s+");
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Each edge line must contain exactly 3 integers");
                }
                
                int source = Integer.parseInt(parts[0]);
                int target = Integer.parseInt(parts[1]);
                int capacity = Integer.parseInt(parts[2]);
                
                if (source < 0 || source >= numNodes) {
                    throw new IllegalArgumentException("Source node out of range: " + source);
                }
                if (target < 0 || target >= numNodes) {
                    throw new IllegalArgumentException("Target node out of range: " + target);
                }
                if (capacity < 0) {
                    throw new IllegalArgumentException("Capacity must be non-negative: " + capacity);
                }
                
                system.plusEdge(source, target, capacity);
            }
            
            return system;
        } finally {
            reader.close();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Flow Network with " + numberNodes + " nodes:\n");
        sb.append("Source: " + source + ", Sink: " + sink + "\n");
        
        List<Integer> sortedVertices = new ArrayList<>(graph.keySet());
        Collections.sort(sortedVertices);
        
        for (Integer u : sortedVertices) {
            sb.append("Vertex " + u + ":\n");
            
            List<Integer> sortedNeighbors = new ArrayList<>(graph.get(u).keySet());
            Collections.sort(sortedNeighbors);
            
            for (Integer v : sortedNeighbors) {
                Edge edge = graph.get(u).get(v);
                sb.append("  -> " + v + ": capacity=")
                  .append(edge.getCapacity() + ", flow=")
                  .append(edge.getFlow() + "\n");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        try {
          
            createSampleNetworkFile("sample_network.txt");
         
            System.out.println("Parsing network from file...");
            Network network = Network.parseFromFile("sample_network.txt");
            
            
            System.out.println(network);
            
           
            System.out.println("Capacity from 0 to 1: " + network.getCapacity(0, 1));
            System.out.println("Capacity from 1 to 3: " + network.getCapacity(1, 3));
            
            
            network.setFlow(0, 1, 5);
            network.setFlow(1, 3, 3);
            network.setFlow(0, 2, 4);
            network.setFlow(2, 3, 4);
            network.setFlow(1, 2, 2);
            
            
            network.setFlow(1, 0, -5);
            network.setFlow(3, 1, -3);
            network.setFlow(2, 0, -4);
            network.setFlow(3, 2, -4);
            network.setFlow(2, 1, -2);
            
           
            System.out.println("\nNetwork after flow assignment:");
            System.out.println(network);
            
            
            int totalFlow = 0;
            for (Integer v : network.getNeighbors(network.getSource())) {
                totalFlow += network.getFlow(network.getSource(), v);
            }
            System.out.println("\nTotal flow from source to sink: " + totalFlow);
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    
    private static void createSampleNetworkFile(String filename) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(filename));
        try {
            writer.println("4");
            writer.println("0 1 6");
            writer.println("0 2 4");
            writer.println("1 2 2");
            writer.println("1 3 3");
            writer.println("2 3 5");
        } finally {
            writer.close();
        }
        System.out.println("Sample network file created: " + filename);
    }
}





